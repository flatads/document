//
//  TCRawDataResponseSerializer.h
//  TCFoundation
//
//  Created by EkoHu on 2021/3/17.
//

/**
 * 序列化包体是未知格式的回包（纯二进制数据或封装信息）
 */

#import <AFNetworking/AFNetworking.h>

NS_ASSUME_NONNULL_BEGIN

@interface TCRawDataResponseSerializer : AFHTTPResponseSerializer

@end

NS_ASSUME_NONNULL_END
