# TCUtil

[![CI Status](https://img.shields.io/travis/chenwenhao/TCUtil.svg?style=flat)](https://travis-ci.org/chenwenhao/TCUtil)
[![Version](https://img.shields.io/cocoapods/v/TCUtil.svg?style=flat)](https://cocoapods.org/pods/TCUtil)
[![License](https://img.shields.io/cocoapods/l/TCUtil.svg?style=flat)](https://cocoapods.org/pods/TCUtil)
[![Platform](https://img.shields.io/cocoapods/p/TCUtil.svg?style=flat)](https://cocoapods.org/pods/TCUtil)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TCUtil is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TCUtil'
```

## Author

chenwenhao, chenwh02@flatincbr.com

## License

TCUtil is available under the MIT license. See the LICENSE file for more info.
